---
name: Vibe Transit
colors:
  surface: '#0b141b'
  surface-dim: '#0b141b'
  surface-bright: '#313a42'
  surface-container-lowest: '#060f16'
  surface-container-low: '#141d24'
  surface-container: '#182128'
  surface-container-high: '#222b33'
  surface-container-highest: '#2d363e'
  on-surface: '#dae3ee'
  on-surface-variant: '#bbcbb9'
  inverse-surface: '#dae3ee'
  inverse-on-surface: '#293139'
  outline: '#869584'
  outline-variant: '#3c4a3d'
  surface-tint: '#3de273'
  primary: '#4ff07f'
  on-primary: '#003915'
  primary-container: '#25d366'
  on-primary-container: '#005523'
  inverse-primary: '#006d2f'
  secondary: '#72d8c8'
  on-secondary: '#003731'
  secondary-container: '#34a192'
  on-secondary-container: '#00302a'
  tertiary: '#a1dbff'
  on-tertiary: '#00344a'
  tertiary-container: '#48c4ff'
  on-tertiary-container: '#004f6c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#66ff8e'
  primary-fixed-dim: '#3de273'
  on-primary-fixed: '#002109'
  on-primary-fixed-variant: '#005322'
  secondary-fixed: '#8ff4e3'
  secondary-fixed-dim: '#72d8c8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005047'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7cd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#0b141b'
  on-background: '#dae3ee'
  surface-variant: '#2d363e'
typography:
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  seat-number:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 12px
  margin-mobile: 16px
  seat-gap: 8px
  container-padding: 20px
---

## Brand & Style
The design system is engineered for a seamless, high-utility booking experience within mobile environments. It targets modern travelers who value efficiency and clarity. The brand personality is **Technical, Efficient, and Focused**, utilizing a **Corporate Modern** style with **Minimalist** influences to reduce cognitive load during complex tasks like seat selection.

The visual mood is defined by a deep monochromatic dark mode that provides a high-contrast backdrop for a "Vibrant Green" action language, signaling progress and confirmation throughout the user journey.

## Colors
The palette is optimized for OLED displays and low-light environments. 
- **Primary Green (#25D366):** Reserved strictly for primary actions, success states, and the "Selected" state in the seat map.
- **Surface Layering:** Uses a three-tier dark neutral system. `Background Canvas` for the deepest layer, `Surface` for cards, and `Container` for interactive elements like inputs and seat units.
- **Semantic Accents:** Red is used exclusively for "Occupied" seats and error validation, while soft blues are used for secondary information like "Floor" toggles.

## Typography
This design system utilizes **Hanken Grotesk** for its exceptional legibility and modern geometric construction. 
- **Numerical Data:** **JetBrains Mono** is employed for labels involving prices, times, and technical specs (like seat inclination) to provide a structured, tabular feel.
- **Hierarchy:** Use `Headline-LG` for main screen titles. `Body-SM` is the workhorse for secondary metadata in flight/bus lists. 
- **Seat Map:** Numbers within the seat grid use a centered, bold weight to ensure clarity at small scale.

## Layout & Spacing
The layout follows a **Fluid Grid** model optimized for narrow viewports.
- **Seat Map Grid:** Implements a strict 4-column layout (2-aisle-2 or 1-aisle-2 configuration). The aisle is represented by a double-width `seat-gap`.
- **Bus Floors:** First and second floors are presented as distinct vertical stacks or side-by-side tabs.
- **Vertical Rhythm:** Elements are spaced in multiples of 4px. Use `margin-mobile` for screen edges and `gutter` for internal card spacing.

## Elevation & Depth
Depth is communicated through **Tonal Layering** rather than heavy shadows to maintain a sleek, integrated look.
- **Level 0:** `Background Canvas` (#0B141B).
- **Level 1:** `Background Surface` (#111B21) - used for the main booking card and seat map container.
- **Level 2:** `Background Container` (#202C33) - used for individual seat units and input fields.
- **Interaction:** Active inputs or selected seats receive a 1.5px stroke of `Primary Green` rather than a shadow.

## Shapes
A "Rounded" strategy is used to soften the technical nature of the UI.
- **Primary Buttons:** High roundedness (1rem) for a friendly, touch-accessible feel.
- **Seats & Inputs:** Standard roundedness (0.5rem).
- **Selection Indicators:** Use the `rounded-lg` (1rem) for floor selection tabs to create a pill-like toggle effect.

## Components
- **Primary Button:** Full-width, `Primary Green` background, dark text (#0B141B), 16px padding.
- **Seat Unit:** A vertical rectangle. 
    - *Available:* `Background Container` with `Text Secondary`.
    - *Selected:* `Primary Green` border (2px) and light green tinted background (10% opacity).
    - *Occupied:* Low-opacity background with a subtle "X" or icon.
- **Floor Toggle:** A segmented control styling. The active floor uses the `Primary Green` or a high-contrast surface color.
- **Minimalist Input:** Transparent background with a `Background Container` border. Labels are pinned to the top-left in `Label-MD`.
- **Trip Card:** Combines `Body-LG` for destinations and `JetBrains Mono` for pricing/times. Includes a divider line to separate outbound and inbound details.